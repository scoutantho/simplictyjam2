arrow ar zqsd (azerty keyboard)
right click so the mouse is inside/outside the game 
don't jump 